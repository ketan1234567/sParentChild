import { Component } from '@angular/core';

@Component({
  selector: 'app-comp1',
  templateUrl: './comp1.component.html',
  styleUrls: ['./comp1.component.css'],
  
})
export class Comp1Component {

  fullname:string='';
  names=[];
  senddata(val1:any,val2:any){
    if(val1!="" && val2!=""){
      this.fullname=val1+ ' '+val2;
    }else{
      this.fullname="";
    }
  }

  sendnames(val:any){
    this.names.push(val);
  }
  
}
