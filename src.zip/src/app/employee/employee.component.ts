import { Component } from '@angular/core';
//console.log("Employee Component loaded..");
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent {

}
