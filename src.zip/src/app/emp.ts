// console.log("emp class loaded.");

export class Emp {
    constructor(){
        console.log("emp constructor called..");
    }
    age:number=25;
    show(){
        console.log("Hello World");
    }
    display(name:string){
        console.log("Hello "+name);
    }
}
