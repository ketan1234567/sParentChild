import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildofchildComponent } from './childofchild.component';

describe('ChildofchildComponent', () => {
  let component: ChildofchildComponent;
  let fixture: ComponentFixture<ChildofchildComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ChildofchildComponent]
    });
    fixture = TestBed.createComponent(ChildofchildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
