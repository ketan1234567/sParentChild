import { Component } from '@angular/core';

@Component({
  selector: 'app-comp2',
  templateUrl: './comp2.component.html',
  styleUrls: ['./comp2.component.css'],
  inputs:['Pdata']
 //inputs:['Pdata1','Pdata2']
 
})
export class Comp2Component {
Pdata:any;
// Pdata1:any;
// Pdata2:any;

}
