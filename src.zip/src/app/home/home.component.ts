import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
//console.log("Home Componnet loaded..");

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  age:number=10;
  constructor(){
    this.age=12;
  }
}
