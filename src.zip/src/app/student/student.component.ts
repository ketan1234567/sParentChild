import { Component, ViewEncapsulation,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css'],
  //encapsulation:ViewEncapsulation.None
  //inputs:['Pdata']
  outputs:['childevent']
})
export class StudentComponent {
  
  //Pdata:any;

  childevent=new EventEmitter();

  senddata(val:any){
    // console.log(val) ;
    this.childevent.emit(val);
  } 
}
