import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { Emp } from './emp';
import { StudentComponent } from './student/student.component';
import { ChildofchildComponent } from './childofchild/childofchild.component';
import { EmployeeComponent } from './employee/employee.component';
import {HttpClientModule} from '@angular/common/http';
import { Comp1Component } from './comp1/comp1.component';
import { Comp2Component } from './comp2/comp2.component';

@NgModule({
  declarations: [
    AppComponent,
    StudentComponent,
    ChildofchildComponent,
    EmployeeComponent,
    Comp1Component,
    Comp2Component,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],//Emp
  bootstrap: [AppComponent]
})
export class AppModule { 

  // constructor(){
  //   console.log("module constructor called");
  // }
}
